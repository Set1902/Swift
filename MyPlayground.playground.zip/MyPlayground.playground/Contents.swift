import UIKit
var phoneNum1: String = "79153408513"
var phoneNum2: String = ""
for char in phoneNum1 {
    phoneNum2 = "+\(char)"
    print(phoneNum2)
}
